#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

const int INF = 1e9;

void solve2() {
    int number;
    string str;
    cin >> number >> str;

    set<char> st;
    string temp = "";

    for(auto x : str) {
        if(st.find(x) == st.end()) {
            temp += x;
            st.insert(x);
        }
    }
    if(!st.empty()) {
        temp += to_string(str.size() - st.size());
    }

    temp = to_string(number) + temp;

    reverse(temp.begin(), temp.end());

    cout << "ilovenam_" + temp << '\n';
}

int findLastnumber(int number) {
    set<int> st;
    int cnt = 1;
    while(true) {
        string str = to_string(cnt * number);
        for(auto x : str) {
            st.insert(x);
        }
        if(st.size() == 10) return cnt * number;
        cnt++;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    solve2();
}
