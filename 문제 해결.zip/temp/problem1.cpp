#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

const int INF = 1e9;

bool is_palindrome(int number) {
    string str = to_string(number);
    int n = str.size();
    for(int i=0, j=n-1; i<j; i++, j--) {
        if(str[i] != str[j]) return false;
    }
    return true;
}

void solve1() {
    int n;
    cin >> n;
    vector<int> ans;
    for(int i=1; i<=n; i++) {
        if(is_palindrome(i)) {
            ans.push_back(i);
        }
    }
    for(int i=0; i<ans.size(); i++) {
        cout << ans[i];
        i+1 != ans.size() ? cout << ", " : cout << "\n";
    }
}


int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    solve1();
    // solve2();
    // solve3();
    // solve4();
}
