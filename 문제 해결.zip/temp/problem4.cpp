#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

const int INF = 1e9;

bool is_possible(vector<vector<int>> &temp, vector<int> &winCount, int now, int target) {
    int remainder = 0;
    for(int i=now; i<temp.size(); i++) {
        for(auto x : temp[i]) {
            if(x == target) remainder++;
        }
    }
    int mx = *max_element(winCount.begin(), winCount.end());
    return mx <= winCount[target] + remainder;
}

int dfs(vector<vector<int>> &temp, vector<int> &winCount, int now, int target) {
    int res = 0;
    if(!is_possible(temp, winCount, now, target)) {
        return 0;
    }
    if(now == temp.size()) {
        int result = *max_element(winCount.begin(), winCount.end());
        bool check = false;
        for(int i=0; i<winCount.size(); i++) {
            if(winCount[i] == result && i == target) {
                check = true;
                continue;
            }
            if(check && winCount[i] == result) {
                return 0;
            }
        }

        if(check) return 1;
        return 0;
    }
    for(int i=0; i<2; i++) {
        winCount[temp[now][i]]++;
        res += dfs(temp, winCount, now+1, target);
        winCount[temp[now][i]]--;

    }
    return res;
}

void solve4() {
    int n,m,k;
    cin >> n >> m >> k;
    vector<int> winCount(n+1, 0);
    vector<vector<int>> nonDeterministic;
    for(int i=0; i<m; i++) {
        int u, v, result;
        cin >> u >> v >> result;
        if(result) {
            result == 1 ? winCount[u]++ :winCount[v]++;
        }else {
            vector<int> temp;
            temp.push_back(u);
            temp.push_back(v);
            nonDeterministic.push_back(temp);
        }
    }
    cout << dfs(nonDeterministic, winCount, 0, k);
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    // solve1();
    // solve2();
    // solve3();
    solve4();
}
