#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

const int INF = 1e9;


int findLastnumber(int number) {
    set<int> st;
    int cnt = 1;
    while(true) {
        string str = to_string(cnt * number);
        for(auto x : str) {
            st.insert(x);
        }
        if(st.size() == 10) return cnt * number;
        cnt++;
    }
}

void solve3() {
    int tt;
    cin >> tt;
    for(int testcase=1; testcase<=tt; testcase++) {
        int number;
        cin >> number;
        if(number == 0) {
            cout << "Case #" << testcase << ": INSOMNIA\n";
        }else {
            cout << "Case #" << testcase << ": " << findLastnumber(number) << "\n";

        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    solve3();
}
